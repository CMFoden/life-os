# Phase 2 Update: Full Editability + Schedules Tab

## What's new

1. **Full registry editability** - Add, edit, delete any item. Change status, owner, rhythm, contacts, details. All saves automatically.
2. **New Schedule tab** - Exercise schedule, social calendar, kid logistics (drop-off/pick-up). All editable.
3. **Editable custody strip** - Tap any day to toggle Newlands/Kommetjie
4. **Google Sheets custody sync** - API endpoint to pull custody from your spreadsheet
5. **5-tab navigation** - Today | Schedule | Lists | Registry | Manual

---

## How to update (5 mins)

### Step 1: Replace LifeOS.js

Open Terminal:
```
cd ~/Desktop/life-os
```

Delete the old file and replace with the new one:
```
cp ~/Downloads/PHASE2-LifeOS.js components/LifeOS.js
```

### Step 2: Add the custody sync API route (optional - for Google Sheets link)

```
mkdir -p app/api/custody
cp ~/Downloads/PHASE2-custody-route.js app/api/custody/route.js
```

Then add this to your `.env.local` file (only if you want Google Sheets sync):
```
CUSTODY_SHEET_URL=your_published_google_sheet_csv_url
```

**How to get the URL:**
1. Open your custody Google Sheet
2. Format columns: `Week Start | Sun | Mon | Tue | Wed | Thu | Fri | Sat | Sun`
3. Use `N` for Newlands, `K` for Kommetjie
4. Go to **File → Share → Publish to web**
5. Choose **CSV** format → click **Publish**
6. Copy the URL

### Step 3: Test locally

```
npm run dev
```

Open http://localhost:3000 and check:
- [ ] Today tab shows status summary, custody, schedule
- [ ] Schedule tab shows exercise, social, kid logistics sections
- [ ] Tap custody days to toggle N/K
- [ ] Tap drop-off/pick-up to cycle through options
- [ ] Add exercise/social entries with the + button
- [ ] Registry: open any item, change status, edit fields
- [ ] Registry: use "+ Add item" button at bottom of any category
- [ ] Registry: delete items with the trash icon
- [ ] Lists still work as before

### Step 4: Deploy

```
git add .
git commit -m "Phase 2: full editability + schedules"
git push
```

Vercel will auto-deploy. If you added the `CUSTODY_SHEET_URL`, also add it in Vercel:
- Vercel dashboard → your project → Settings → Environment Variables
- Add `CUSTODY_SHEET_URL` = your CSV URL

---

## What each section does

### Schedule Tab
- **Week toggle** - Switch between this week and next week
- **Custody strip** - Tap any day to flip between NWL/KOM (saves instantly)
- **Exercise** - Add entries per day (Chloë/Cameron/Together + what). Tap + to add, × to remove.
- **Social** - Same format with more people options (Tom, Luke, C+C, T+L, Family)
- **Kid Logistics** - Tap drop-off/pick-up to cycle through: — → Chloë → Cameron → Together → JP → Patrick. Tap 📝 for notes.

### Registry Editability
- **Status buttons** - Tap to change between "Needs love", "Heads up", "Handled"
- **Edit mode** - Tap ✏️ to edit name, owner, rhythm, next due, action, notes, details
- **Contacts** - Add/remove contacts on any item. Tap to call.
- **Details** - Add custom key-value details (e.g. brand: Samsung)
- **Delete** - Tap 🗑️ then confirm. Two-step to prevent accidents.
- **Add item** - Tap "+ Add item" at the bottom of any category

---

## Troubleshooting

**New schedule data not showing**
→ The new data keys (exercise_schedule, social_schedule, kid_logistics) are created automatically on first load. If you had old data, it won't conflict.

**Old data looks different**
→ The registry structure is backwards compatible. Your existing data will load fine.

**Changes not saving**
→ Check the "Saving..." indicator in the top right. If it never appears, check your Supabase connection.

**Anything else**
→ Copy the exact error and paste it to me.
